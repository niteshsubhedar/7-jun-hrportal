package com.mindgate.main.service;

import java.util.List;

import com.mindgate.main.pojo.ProjectDetails;

public interface ProjectDetailsServiceInterface {

	public boolean addNewProjectDetails(ProjectDetails projectDetails);
	public boolean updateProjectDeatilsByProjectId(ProjectDetails projectDetails);
	public boolean deleteProjectDetailsByProjectId(int projectId);
	public ProjectDetails getProjectDetailsByProjectId(int projectId);
	public List<ProjectDetails> getAllProjectsDetails();

}
