package com.mindgate.main.pojo;

public class CandidateDetails {
	private int candidateId;
	private String candidateName;
	private String emailId;
	private String skill1;
	private String skill2;
	private String skill3;
	private String qualification;
	private String experience;
	private String status;
	private String location;
	private RequirementRequestDetails requirementrequestetails;
	
	
	public CandidateDetails() {
		// TODO Auto-generated constructor stub
	}


	public CandidateDetails(int candidateId, String candidateName, String emailId, String skill1, String skill2,
			String skill3, String qualification, String experience, String status, String location,
			RequirementRequestDetails requirementrequestetails) {
		super();
		this.candidateId = candidateId;
		this.candidateName = candidateName;
		this.emailId = emailId;
		this.skill1 = skill1;
		this.skill2 = skill2;
		this.skill3 = skill3;
		this.qualification = qualification;
		this.experience = experience;
		this.status = status;
		this.location = location;
		this.requirementrequestetails = requirementrequestetails;
	}


	public int getCandidateId() {
		return candidateId;
	}


	public void setCandidateId(int candidateId) {
		this.candidateId = candidateId;
	}


	public String getCandidateName() {
		return candidateName;
	}


	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}


	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	public String getSkill1() {
		return skill1;
	}


	public void setSkill1(String skill1) {
		this.skill1 = skill1;
	}


	public String getSkill2() {
		return skill2;
	}


	public void setSkill2(String skill2) {
		this.skill2 = skill2;
	}


	public String getSkill3() {
		return skill3;
	}


	public void setSkill3(String skill3) {
		this.skill3 = skill3;
	}


	public String getQualification() {
		return qualification;
	}


	public void setQualification(String qualification) {
		this.qualification = qualification;
	}


	public String getExperience() {
		return experience;
	}


	public void setExperience(String experience) {
		this.experience = experience;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public RequirementRequestDetails getRequirementrequestetails() {
		return requirementrequestetails;
	}


	public void setRequirementrequestetails(RequirementRequestDetails requirementrequestetails) {
		this.requirementrequestetails = requirementrequestetails;
	}


	@Override
	public String toString() {
		return "CandidateDetails [candidateId=" + candidateId + ", candidateName=" + candidateName + ", emailId="
				+ emailId + ", skill1=" + skill1 + ", skill2=" + skill2 + ", skill3=" + skill3 + ", qualification="
				+ qualification + ", experience=" + experience + ", status=" + status + ", location=" + location
				+ ", requirementrequestetails=" + requirementrequestetails + "]";
	}


			
}
