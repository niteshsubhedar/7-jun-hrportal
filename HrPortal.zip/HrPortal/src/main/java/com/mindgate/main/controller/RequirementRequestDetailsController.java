package com.mindgate.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.pojo.ProjectDetails;
import com.mindgate.main.pojo.RequirementRequestDetails;
import com.mindgate.main.service.RequirementRequestDetailsServiceInterface;

@RestController
@CrossOrigin(origins = "http://localhost:4200/")
@RequestMapping("requirementrequestdetails")
public class RequirementRequestDetailsController {

	@Autowired
	private RequirementRequestDetailsServiceInterface requestDetailsServiceInterface; 
	
	@RequestMapping(value = "requirementrequestdetail" , method = RequestMethod.GET)
	public List<RequirementRequestDetails> getAllRequirementRequest(){
		return requestDetailsServiceInterface.getAllRequirementRequest();
	}
	
	@RequestMapping(value = "requirementrequestdetail/{requirementrequestid}" , method = RequestMethod.GET)
	public RequirementRequestDetails getRequirementRequestByRequirementRequestId(@PathVariable int requirementrequestid) {
		return requestDetailsServiceInterface.getRequirementRequestByRequirementRequestId(requirementrequestid);
	}
}
