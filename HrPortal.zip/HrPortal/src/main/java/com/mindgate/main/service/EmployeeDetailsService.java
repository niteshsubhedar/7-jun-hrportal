package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.pojo.EmployeeDetails;
import com.mindgate.main.repository.EmployeeDetailsRepositoryInterface;

@Service
public class EmployeeDetailsService implements EmployeeDetailsServiceInterface{

	@Autowired
	private EmployeeDetailsRepositoryInterface employeeDetailsRepository;
	
	
	@Override
	public boolean addNewEmployee(EmployeeDetails employeeDetails) {

		return employeeDetailsRepository.addNewEmployee(employeeDetails);
	}

	@Override
	public boolean updateEmployeeDetailsByEmployeeId(EmployeeDetails employeeDetails) {
		return employeeDetailsRepository.updateEmployeeDetailsByEmployeeId(employeeDetails);
	}

	@Override
	public boolean deleteEmployeeByEmployeeId(int employeeId) {
		return employeeDetailsRepository.deleteEmployeeByEmployeeId(employeeId);
	}

	@Override
	public EmployeeDetails getEmployeeByEmployeeId(int employeeId) {
		return employeeDetailsRepository.getEmployeeByEmployeeId(employeeId);
	}

	@Override
	public List<EmployeeDetails> getAllEmployee() {
		return employeeDetailsRepository.getAllEmployee();
	}

}
