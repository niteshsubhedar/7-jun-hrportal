package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.pojo.InterviewDetails;
import com.mindgate.main.repository.InterviewDetailsRepositoryInterface;

@Service
public class InterviewDetailsService implements InterviewDetailsServiceInterface {

	@Autowired
	private InterviewDetailsRepositoryInterface interviewDetailsRepository;
	@Override
	public boolean addNewInterviewDetails(InterviewDetails interviewDetails) {

		return interviewDetailsRepository.addNewInterviewDetails(interviewDetails);
	}

	@Override
	public boolean updateInterviewDetailsByInterviewId(InterviewDetails interviewDetails) {

		return interviewDetailsRepository.updateInterviewDetailsByInterviewId(interviewDetails);
	}

	@Override
	public boolean deleteInterviewDetailsByInterviewId(int interviewId) {
		// TODO Auto-generated method stub
		return interviewDetailsRepository.deleteInterviewDetailsByInterviewId(interviewId);
	}

	@Override
	public InterviewDetails getInterviewDetailsById(int interviewId) {
		// TODO Auto-generated method stub
		return interviewDetailsRepository.getInterviewDetailsById(interviewId);
	}

	@Override
	public List<InterviewDetails> getAllInterviewDetails() {
		// TODO Auto-generated method stub
		return interviewDetailsRepository.getAllInterviewDetails();
	}

}
