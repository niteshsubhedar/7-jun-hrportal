package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.pojo.DocumentDetails;

public interface DocumentDetailsRepositoryInterface {
	
	public boolean addNewDocumentDetails(DocumentDetails documentDetails);
	public boolean updateDocumentDetailsByDocumentId(DocumentDetails documentDetails);
	public boolean deleteDocumentDetailsByDocumentId(int documentId);
	public DocumentDetails getDocumentDetailsByDocumentId(int documentId);
	public List<DocumentDetails> getAllDocumentDetails();
	 
}
