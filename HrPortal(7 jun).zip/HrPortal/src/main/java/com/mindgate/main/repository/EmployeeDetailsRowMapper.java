package com.mindgate.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mindgate.main.pojo.EmployeeDetails;
import com.mindgate.main.pojo.LoginDetails;
import com.mindgate.main.pojo.ProjectDetails;

public class EmployeeDetailsRowMapper implements RowMapper<EmployeeDetails>{

	@Override
	public EmployeeDetails mapRow(ResultSet rs, int rowNum) throws SQLException {	 
		
		 int employeeId = rs.getInt("EMPLOYEE_ID");
		 String firstName = rs.getString("FIRST_NAME");
		 String lastName = rs.getString("LAST_NAME");
		 int contactNumber = rs.getInt("CONTACT_NO");
		 String designation = rs.getString("DESIGNATION");
		 Double salary = rs.getDouble("SALARY");
		 ProjectDetails projectDetails = (ProjectDetails) rs.getObject("PROJECT_ID");
		 String address = rs.getString("ADDRESS");
		 String city = rs.getString("CITY");
		 String state = rs.getString("STATE");
		 int pincode = rs.getInt("PINCODE");
		 LoginDetails loginDetails = (LoginDetails) rs.getObject("USER_ID");
		 
		 EmployeeDetails employeeDetails = new EmployeeDetails(employeeId, firstName, lastName, contactNumber, designation, salary, projectDetails, address, city, state, pincode, loginDetails);		 
		 
		return null;
		 
		
	}

}
