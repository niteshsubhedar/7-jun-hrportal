package com.mindgate.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mindgate.main.pojo.EmployeeDetails;
import com.mindgate.main.pojo.ProjectDetails;
import com.mindgate.main.pojo.RequirementRequestDetails;

public class RequirementRequestDetailsRowMapper implements RowMapper<RequirementRequestDetails>{

	@Override
	public RequirementRequestDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		
		int requirementRequestId = rs.getInt("employee_id");
		ProjectDetails projectDetails= (ProjectDetails) rs.getObject("PROJECT_ID");
		String skill1 = rs.getString("SKILL1");
		String skill2 = rs.getString("SKILL2");
		String skill3 = rs.getString("SKILL3");
		int experience = rs.getInt("EXPERIENCE");
		int vacancies = rs.getInt("VACANCIES");;
		EmployeeDetails employeeDetails= (EmployeeDetails) rs.getObject("TEAM_LEADER_ID");
		String status = rs.getString("STATUS");
		String role = rs.getString("ROLE");
		
		RequirementRequestDetails requirementRequestDetails = new RequirementRequestDetails(requirementRequestId,
				projectDetails,skill1,skill2,skill3,experience,vacancies,employeeDetails,status,role);
		return requirementRequestDetails;
	}

}
//PROJECT_ID, SKILL1, SKILL2, SKILL3, EXPERIENCE, VACANCIES, TEAM_LEADER_ID,STATUS, ROLE