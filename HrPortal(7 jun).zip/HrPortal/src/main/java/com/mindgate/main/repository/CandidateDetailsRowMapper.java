package com.mindgate.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.mindgate.main.pojo.CandidateDetails;
import com.mindgate.main.pojo.EmployeeDetails;
import com.mindgate.main.pojo.ProjectDetails;
import com.mindgate.main.pojo.RequirementRequestDetails;

public class CandidateDetailsRowMapper implements RowMapper<CandidateDetails> {

	@Override
	public CandidateDetails mapRow(ResultSet rs, int rowNum) throws SQLException {

		
		int candidateId = rs.getInt("CANDIDATE_ID");
		String candidateName = rs.getString("CANDIDATE_NAME");
		String emailId = rs.getString("EMAIL_ID");
		String skill1 = rs.getString("SKILL1");
		String skill2 = rs.getString("SKILL2");
		String skill3 = rs.getString("SKILL3");
		String qualification = rs.getString("QUALIFICATION");
		String experience = rs.getString("EXPERIENCE");
		String status = rs.getString("STATUS");
		String location = rs.getString("LOCATION");
		RequirementRequestDetails requirementrequestetails = (RequirementRequestDetails) rs
				.getObject("REQUIREMENT_REQUEST_DETAILS");

		CandidateDetails candidateDetails = new CandidateDetails(candidateId, candidateName, emailId,skill1, skill2, skill3, qualification,
				experience, status, location ,requirementrequestetails);
		return candidateDetails;
	}

}
